import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-courses-with-json',
  templateUrl: './courses-with-json.component.html',
  styleUrls: ['./courses-with-json.component.css']
})

export class CoursesWithJsonComponent implements OnInit {
  jsonData:any[];
  constructor(private courseservice:CourseService) { }

  ngOnInit() {
    this.courseservice.getCourseData().subscribe((data:any[])=>this.jsonData=data)
  }

}
